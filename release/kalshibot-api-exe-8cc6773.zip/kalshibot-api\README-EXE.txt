KalshiBot API EXE package

1) (Optional) copy .env.example to .env and edit API keys.
2) Double-click start-kalshibot-api.bat
3) Open http://127.0.0.1:8765/docs

Notes:
- This package runs the backend API only.
- Frontend Vite dashboard is not bundled in this EXE package.
- Data files are written under .\data by default.
