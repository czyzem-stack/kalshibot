@echo off
setlocal
cd /d "%~dp0"
if "%KALSHI_BOT_PORT%"=="" set KALSHI_BOT_PORT=8765
echo Starting KalshiBot API on http://127.0.0.1:%KALSHI_BOT_PORT%
kalshibot-api.exe
